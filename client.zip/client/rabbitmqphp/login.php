<?php
session_start();

require_once __DIR__. '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$name = $_POST['name'];
$email = $_POST['email'];
$role = $_POST['role'];
$password = $_POST['password'];

// Vérification des informations de connexion
if ($password == 'admin') { // Simple authentication example
    $_SESSION['user'] = $name;
    $_SESSION['email'] = $email;
    $_SESSION['role'] = $role;

    // Envoi des données à RabbitMQ
    try {
        $rabbitmq_host = 'localhost';
        $connection = new AMQPStreamConnection($rabbitmq_host, 5672, 'admin', 'admin2017');
        $channel = $connection->channel();

        $channel->queue_declare('employee_info', false, false, false, false);

        $data = array(
            'name' => $name,
            'email' => $email,
            'role' => $role
        );

        $json_data = json_encode($data);
        $msg = new AMQPMessage($json_data);

        $channel->basic_publish($msg, '', 'employee_info');

        $channel->close();
        $connection->close();
    } catch (Exception $e) {
        echo 'Erreur : ' . $e->getMessage();
        exit();
    }

    // Redirection vers la page d'action choisie
    header("Location: choose_action.html");
    exit();
} else {
    echo "Identifiants incorrects";
}
?>
