<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit();
}

$action = $_POST['action'];

if ($action == 'create') {
    header("Location: creation.html");
} elseif ($action == 'resolve') {
    header("Location: resolve_ticket.php");
} elseif ($action == 'close') {
    header("Location: close_ticket.php");  // Reusing the same form for close
} else {
    echo "Action inconnue";
}
?>
