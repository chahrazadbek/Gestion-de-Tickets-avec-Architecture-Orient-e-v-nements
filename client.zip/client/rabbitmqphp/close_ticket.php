<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clôturer les Tickets</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #00bcd4, #009688);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }
        form {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
        }
        label {
            margin-bottom: 10px;
            font-weight: bold;
            color: #555;
            text-align: left;
        }
        input[type="text"] {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        input[type="text"]:focus {
            border-color: #009688;
            box-shadow: 0 0 8px rgba(0, 150, 136, 0.5);
        }
        button {
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #009688;
            color: white;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #00796b;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background-color: #f4f4f4;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            text-align: left;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .ticket-details {
            color: #555;
            margin-bottom: 5px;
        }
        .ticket-status {
            font-weight: bold;
            color: #009688;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Tickets Résolus à Clôturer</h1>
        <ul>
            <?php
            $tickets = [];

            // Vérifier si le fichier JSON existe
            if (file_exists('resolved_tickets.json')) {
                // Lire le contenu du fichier JSON
                $json_data = file_get_contents('resolved_tickets.json');

                // Vérifier si la lecture du fichier a réussi
                if ($json_data === false) {
                    echo "<p>Erreur : impossible de lire le fichier JSON.</p>";
                } else {
                    // Décoder les données JSON
                    $tickets = json_decode($json_data, true);

                    // Vérifier si le décodage a réussi
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        echo "<p>Erreur : problème de décodage JSON. " . json_last_error_msg() . "</p>";
                    }
                }
            } else {
                echo "<p>Erreur : le fichier resolved_tickets.json n'existe pas.</p>";
            }

            // Afficher les tickets résolus
            if (!empty($tickets)) {
                foreach ($tickets as $ticket) {
                    if ($ticket['status'] === 'resolved') {
                        echo "<li>";
                        echo "<div class='ticket-details'>ID: " . htmlspecialchars($ticket['id']) . "</div>";
                        echo "<div class='ticket-details'>Sujet: " . htmlspecialchars($ticket['subject']) . "</div>";
                        echo "<div class='ticket-details'>Description: " . htmlspecialchars($ticket['description']) . "</div>";
                        echo "<div class='ticket-details'>Priorité: " . htmlspecialchars($ticket['priority']) . "</div>";
                        echo "<div class='ticket-status'>Statut: " . htmlspecialchars($ticket['status']) . "</div>";
                        echo "</li>";
                    }
                }
            } else {
                echo "<p>Aucun ticket à afficher.</p>";
            }
            ?>
        </ul>
        <form method="post" action="close_ticket_action.php">
            <label for="ticket_id">ID du ticket à clôturer:</label>
            <input type="text" id="ticket_id" name="ticket_id" required>
            <button type="submit">Clôturer le ticket</button>
        </form>
    </div>
</body>
</html>