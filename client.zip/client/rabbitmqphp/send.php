<?php
require_once __DIR__ . '/vendor/autoload.php'; // Inclure la bibliothèque AMQP
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

// Vérification des données reçues depuis le formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Extraction et vérification des données du formulaire
    $subject = $_POST['subject'] ?? '';
    $description = $_POST['description'] ?? '';
    $priority = $_POST['priority'] ?? '';

    // Vérification si les champs requis sont remplis
    if (!empty($subject) && !empty($description) && !empty($priority)) {
        // Paramètres de connexion à RabbitMQ
        $rabbitmq_host = 'localhost';
        $connection = new AMQPStreamConnection($rabbitmq_host, 5672, 'admin', 'admin2017');
        $channel = $connection->channel();

        // Déclaration de la file d'attente à partir de laquelle le message sera envoyé
        $channel->queue_declare('ticket_creation', false, false, false, false);

        // Création d'un tableau associatif contenant les données du formulaire
        $data = [
            'subject' => $subject,
            'description' => $description,
            'priority' => $priority,
            'status' => 'created'
        ];

        // Encodage des données en JSON
        $json_data = json_encode($data);

        // Création d'un message AMQP avec les données encodées
        $msg = new AMQPMessage($json_data);

        // Envoi du message à la file d'attente
        $channel->basic_publish($msg, '', 'ticket_creation');

        // Fermeture de la connexion
        $channel->close();
        $connection->close();

        echo "Le ticket a été créé et envoyé à RabbitMQ.\n";
        echo "Sujet: $subject, Description: $description, Priorité: $priority\n";
    } else {
        echo "Veuillez remplir tous les champs du formulaire.\n";
    }
} else {
    echo "Erreur : Méthode de requête non autorisée.\n";
}
?>
