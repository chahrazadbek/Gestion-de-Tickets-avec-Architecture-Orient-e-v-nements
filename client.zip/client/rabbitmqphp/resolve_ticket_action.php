<?php
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticket_id_in_progress = $_POST['ticket_id_in_progress'] ?? null;
    $ticket_id_resolved = $_POST['ticket_id_resolved'] ?? null;

    if (file_exists('resolved_tickets.json')) {
        $json_data = file_get_contents('resolved_tickets.json');
        $tickets = json_decode($json_data, true);

        // Connexion à RabbitMQ
        $connection = new AMQPStreamConnection('localhost', 5672, 'admin', 'admin2017');
        $channel = $connection->channel();

        // Déclaration de la file d'attente pour la mise à jour des tickets
        $channel->queue_declare('update_ticket_queue', false, false, false, false);

        if ($ticket_id_in_progress) {
            foreach ($tickets as &$ticket) {
                if ($ticket['id'] == $ticket_id_in_progress) {
                    $ticket['status'] = 'in_progress';
                    echo "Le ticket avec ID " . htmlspecialchars($ticket_id_in_progress) . " est maintenant en cours de résolution.";

                    // Création du message
                    $data = array(
                        'id' => $ticket_id_in_progress,
                        'status' => 'in_progress'
                    );
                    $json_data = json_encode($data);
                    $msg = new AMQPMessage($json_data);

                    // Envoi du message à RabbitMQ
                    $channel->basic_publish($msg, '', 'update_ticket_queue');
                    echo " Le statut du ticket a été envoyé à RabbitMQ.\n";
                }
            }
        } elseif ($ticket_id_resolved) {
            foreach ($tickets as &$ticket) {
                if ($ticket['id'] == $ticket_id_resolved) {
                    $ticket['status'] = 'resolved';
                    echo "Le ticket avec ID " . htmlspecialchars($ticket_id_resolved) . " a été résolu.";

                    // Création du message
                    $data = array(
                        'id' => $ticket_id_resolved,
                        'status' => 'resolved'
                    );
                    $json_data = json_encode($data);
                    $msg = new AMQPMessage($json_data);

                    // Envoi du message à RabbitMQ
                    $channel->basic_publish($msg, '', 'update_ticket_queue');
                    echo " Le statut du ticket a été envoyé à RabbitMQ.\n";
                }
            }
        }

        // Écrire les modifications dans le fichier JSON
        file_put_contents('resolved_tickets.json', json_encode($tickets));

        // Fermeture de la connexion
        $channel->close();
        $connection->close();
    } else {
        echo "Aucun ticket trouvé.";
    }
} else {
    echo "Méthode non autorisée.";
}
?>