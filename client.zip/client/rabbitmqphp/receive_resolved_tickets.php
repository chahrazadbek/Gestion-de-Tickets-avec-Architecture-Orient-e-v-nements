<?php
require_once __DIR__ . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;

session_start();

$connection = new AMQPStreamConnection('localhost', 5672, 'admin', 'admin2017');
$channel = $connection->channel();

$channel->queue_declare('send_tickets_queue', false, false, false, false);

echo 'En attente de tickets résolus. Pour arrêter, appuyez sur CTRL+C', "\n";

$callback = function($msg) {
    $tickets = json_decode($msg->body, true); // Decode the entire list of tickets from the message body

    // Save the entire list to the JSON file
    file_put_contents('resolved_tickets.json', json_encode($tickets));
    
    echo "Liste des tickets reçue et sauvegardée dans resolved_tickets.json : ", print_r($tickets, true), "\n";
};

$channel->basic_consume('send_tickets_queue', '', false, true, false, false, $callback);

while ($channel->is_consuming()) {
    $channel->wait();
}

$channel->close();
$connection->close();
?>