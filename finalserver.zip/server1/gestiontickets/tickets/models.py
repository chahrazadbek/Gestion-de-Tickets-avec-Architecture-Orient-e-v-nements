from django.db import models

class Ticket(models.Model):
    STATUS_CHOICES = [
        ('created', 'Ticket Créé'),
        ('in_progress', 'En Train de Résoudre'),
        ('resolved', 'Résolu'),
        ('closed', 'Clôturé'),
    ]
    PRIORITIES=(
        ('B','Basse'),
        ('M','Moyenne'),
        ('H','Haute'),
    )

    subject = models.CharField(max_length=255)
    description = models.TextField()
    priority = models.CharField(max_length=50,choices=PRIORITIES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='created')
    created_at=models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return f"{self.subject} - {self.status}"

class Employee(models.Model):
    ROLE_CHOICES = (
        ('administrateur', 'Administrateur'),
        ('utilisateur_final', 'Utilisateur Final'),
        ('technicien', 'Technicien'),
    )

    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    password = models.CharField(max_length=255)  # Stocker le mot de passe hashé

    def _str_(self):
        return self.name
    
   