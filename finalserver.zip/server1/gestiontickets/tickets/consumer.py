import pika
import json
from django.conf import settings
from django.db import models

# Listes globales pour stocker les tickets et les employés
tickets_list = []
employees_list = []

# Function to process ticket creation messages
def process_create_ticket_message(ch, method, properties, body):
    from .models import Ticket
    ticket_data = json.loads(body)
    ticket = Ticket.objects.create(
        subject=ticket_data['subject'],
        description=ticket_data['description'],
        priority=ticket_data['priority'],
        status=ticket_data.get('status', 'created')
    )
    print("Nouveau ticket créé :", ticket_data)

    # Ajouter le nouveau ticket à la liste globale
    tickets_list.append({
        'id': ticket.id,
        'subject': ticket.subject,
        'description': ticket.description,
        'priority': ticket.priority,
        'status': ticket.status,
    })

# Function to process ticket update messages
def process_update_ticket_message(ch, method, properties, body):
    from .models import Ticket
    ticket_data = json.loads(body)
    ticket_id = ticket_data['id']
    status = ticket_data['status']

    try:
        ticket = Ticket.objects.get(id=ticket_id)
        ticket.status = status
        ticket.save()
        print(f"Statut du ticket {ticket_id} mis à jour en '{status}' dans la base de données.")
    except Ticket.DoesNotExist:
        print(f"Le ticket avec ID {ticket_id} n'existe pas.")

# Function to process employee information messages
def process_employee_info_message(ch, method, properties, body):
    from .models import Employee
    try:
        employee_data = json.loads(body)
        name = employee_data.get('name')
        email = employee_data.get('email')
        role = employee_data.get('role')
        password = employee_data.get('password')  # Assurez-vous que le mot de passe est déjà hashé

        if name and email and role:
            employee = Employee.objects.create(
                name=name,
                email=email,
                role=role,
                password=password
            )
            print("Nouvel employé créé :", employee_data)

            # Ajouter le nouvel employé à la liste globale
            employees_list.append({
                'id': employee.id,
                'name': employee.name,
                'email': employee.email,
                'role': employee.role,
            })
        else:
            print("Données incomplètes pour créer un employé :", employee_data)
    except json.JSONDecodeError as e:
        print(f"Erreur JSON lors du traitement du message : {e}")
    except KeyError as e:
        print(f"Clé manquante dans les données de l'employé : {e}")

# Function to send the final list of tickets and employees to RabbitMQ
def send_data_to_rabbitmq():
    global tickets_list, employees_list
    if tickets_list:
        print("Envoi de la liste des tickets à RabbitMQ :", tickets_list)
        # Code pour envoyer la liste des tickets à RabbitMQ ici
    if employees_list:
        print("Envoi de la liste des employés à RabbitMQ :", employees_list)
        # Code pour envoyer la liste des employés à RabbitMQ ici

def start_consumer():
    connection = pika.BlockingConnection(pika.ConnectionParameters(
        settings.RABBITMQ_HOST,
        settings.RABBITMQ_PORT,
        '/',
        pika.PlainCredentials(settings.RABBITMQ_USERNAME, settings.RABBITMQ_PASSWORD)
    ))
    channel = connection.channel()

    # Declare the queues
    channel.queue_declare(queue='ticket_creation')
    channel.basic_consume(queue='ticket_creation', on_message_callback=process_create_ticket_message, auto_ack=True)
    
    channel.queue_declare(queue='update_ticket_queue')
    channel.basic_consume(queue='update_ticket_queue', on_message_callback=process_update_ticket_message, auto_ack=True)

    channel.queue_declare(queue='employee_info')
    channel.basic_consume(queue='employee_info', on_message_callback=process_employee_info_message, auto_ack=True)

    print("En attente de messages. Pour arrêter, appuyez sur CTRL+C")
    try:
        channel.start_consuming()
    except KeyboardInterrupt:
        channel.stop_consuming()

    # Envoi final des listes des tickets et des employés à RabbitMQ
    send_data_to_rabbitmq()

if __name__ == "__main__":
    start_consumer()

