
    

from django.http import JsonResponse
import pika
import json
from django.conf import settings
from django.db import connection
from .models import Ticket



def reset_ticket_sequence():
    with connection.cursor() as cursor:
        cursor.execute("DELETE FROM sqlite_sequence WHERE name='tickets_ticket';")  # 'tickets_ticket' est le nom de votre table Ticket

def create_ticket(request):
    from .models import Ticket  # Importez à l'intérieur de la fonction
    if request.method == 'POST':
        data = json.loads(request.body)
        create_ticket_from_data(data)
        send_tickets_to_rabbitmq()  # Envoyer la liste des tickets après en avoir créé un
        return JsonResponse({'message': 'Ticket créé avec succès à partir des données reçues de RabbitMQ'})
    else:
        return JsonResponse({'error': 'Méthode non autorisée'}, status=405)

def create_ticket_from_data(data):
    from .models import Ticket  # Importez à l'intérieur de la fonction
    Ticket.objects.create(subject=data['subject'], description=data['description'], priority=data['priority'],status=data['status'])
    print(f"Ticket créé avec succès: {data}")  # Ajout d'un log pour la création de ticket

def send_tickets_to_rabbitmq():
    from .models import Ticket  # Importez à l'intérieur de la fonction
    tickets = Ticket.objects.all()
    ticket_list = [ {"id": ticket.id, "subject": ticket.subject, "description": ticket.description, "priority": ticket.priority, "status": ticket.status } for ticket in tickets]

    message = json.dumps(ticket_list)

    connection = pika.BlockingConnection(pika.ConnectionParameters(settings.RABBITMQ_HOST, settings.RABBITMQ_PORT, '/', pika.PlainCredentials(settings.RABBITMQ_USERNAME, settings.RABBITMQ_PASSWORD)))
    channel = connection.channel()

    channel.queue_declare(queue='send_tickets_queue')

    channel.basic_publish(exchange='', routing_key='send_tickets_queue', body=message)
    connection.close()

    print("envoyés à RabbitMQ avec succès!")
    print("Liste des tickets envoyée: ", ticket_list)  # Ajout d'un log pour les tickets envoyés

