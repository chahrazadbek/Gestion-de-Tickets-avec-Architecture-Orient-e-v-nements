
# tickets/urls.py
from django.urls import path
from .views import create_ticket, send_tickets_to_rabbitmq

urlpatterns = [
    path('create-ticket/', create_ticket, name='create_ticket'),
    path('send-tickets/', send_tickets_to_rabbitmq, name='send_tickets'),
]